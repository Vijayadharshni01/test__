using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EZone.Models;
using EZone.Business.Interface;
using EZone.Repositories.Interface;
using Microsoft.AspNetCore.Identity;

namespace EZone.Business.Service
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _repo;
        private readonly UserManager<User> _userManager;

        public UserService(IUserRepository repo, UserManager<User> userManager)
        {
            _repo = repo;
            _userManager = userManager;
        }

        public async Task<User> AuthenticateAsync(string username, string password)
        {
            var user = await _repo.GetByUsernameAsync(username);
            if (user == null) return null;
            var result = await _userManager.CheckPasswordAsync(user, password);
            if (!result) return null;
            return user;
        }

        public async Task<User> GetByIdAsync(string id)
        {
            return await _repo.GetByIdAsync(id);
        }

        public async Task<User> RegisterAsync(User user, string password)
        {
            var result = await _userManager.CreateAsync(user, password);
            if (result.Succeeded)
            {
                // Assign role to the user in Identity system
                if (!string.IsNullOrEmpty(user.Role))
                {
                    await _userManager.AddToRoleAsync(user, user.Role);
                }
                return user;
            }
            return null;
        }

        public async Task<User> UpdateProfileAsync(User updatedUser)
        {
            return await _repo.UpdateProfileAsync(updatedUser);
        }

        public async Task<User> GetProfileAsync(string id)
        {
            return await _repo.GetByIdAsync(id);
        }
    }
}
