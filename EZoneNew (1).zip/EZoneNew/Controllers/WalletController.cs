using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using EZone.Business.Interface;

namespace EZone.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class WalletController : ControllerBase
    {
        private readonly IWalletService _walletService;

        public WalletController(IWalletService walletService)
        {
            _walletService = walletService;
        }

        // 💰 Get wallet balance
        [HttpGet("balance")]
        public async Task<IActionResult> GetBalance()
        {
            try
            {
                var userId = User.FindFirst("id")?.Value;
                if (string.IsNullOrEmpty(userId))
                    return Unauthorized(new { message = "Invalid or missing user token" });

                var balance = await _walletService.GetBalanceAsync(userId);
                return Ok(new { balance });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving wallet balance", error = ex.Message });
            }
        }

        // 💰 Add money to wallet
        [HttpPost("add")]
        public async Task<IActionResult> AddMoney([FromQuery] decimal amount)
        {
            try
            {
                var userId = User.FindFirst("id")?.Value;
                if (string.IsNullOrEmpty(userId))
                    return Unauthorized(new { message = "Invalid or missing user token" });

                if (amount <= 0)
                    return BadRequest(new { message = "Amount must be greater than zero" });

                var success = await _walletService.AddAmountAsync(userId, amount);
                if (!success)
                    return BadRequest(new { message = "Failed to add money to wallet" });

                var newBalance = await _walletService.GetBalanceAsync(userId);
                return Ok(new { message = "Money added successfully", balance = newBalance });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error adding money to wallet", error = ex.Message });
            }
        }

        // 💰 Get wallet details
        [HttpGet]
        public async Task<IActionResult> GetWallet()
        {
            try
            {
                var userId = User.FindFirst("id")?.Value;
                if (string.IsNullOrEmpty(userId))
                    return Unauthorized(new { message = "Invalid or missing user token" });

                var wallet = await _walletService.GetWalletAsync(userId);
                if (wallet == null)
                {
                    // Create wallet if it doesn't exist
                    wallet = await _walletService.CreateWalletAsync(userId);
                }

                return Ok(wallet);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving wallet", error = ex.Message });
            }
        }
    }
}
