using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace EZone.Models
{
    public class Wallet
    {
        [Key]
        public int Id { get; set; }
        public string UserId { get; set; }
        public decimal Balance { get; set; } = 0m;
    }
}