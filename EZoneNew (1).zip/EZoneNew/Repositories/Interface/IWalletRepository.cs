using EZone.Models;

namespace EZone.Repositories.Interface
{
    public interface IWalletRepository
    {
        Task<Wallet?> GetWalletByUserIdAsync(string userId);
        Task<Wallet> CreateWalletAsync(string userId);
        Task<bool> UpdateWalletAsync(Wallet wallet);
        Task<bool> DeductAmountAsync(string userId, decimal amount);
        Task<bool> AddAmountAsync(string userId, decimal amount);
    }
}
