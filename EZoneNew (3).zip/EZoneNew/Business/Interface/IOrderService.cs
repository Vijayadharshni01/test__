using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EZone.Models;
namespace EZone.Business.Interface
{
    public interface IOrderService
    {
        Task<Order> PlaceOrderAsync(string userId, string paymentMethod);
        Task<IEnumerable<Order>> GetOrdersAsync(string userId);
        Task<bool> CancelOrderAsync(int orderId, string userId);
        Task<bool> DeleteOrderAsync(int orderId, string userId);
    }
}