using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EZone.Models;
namespace EZone.Business.Interface
{
    public interface IUserService
    {
        Task<User> RegisterAsync(User user, string password);
        Task<User> AuthenticateAsync(string username, string password);
        Task<User> GetByIdAsync(string id);
        Task<User> UpdateProfileAsync(User updatedUser);
        Task<User> GetProfileAsync(string id);

    }
}