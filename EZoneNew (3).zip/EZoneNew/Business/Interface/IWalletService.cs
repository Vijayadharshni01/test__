using EZone.Models;

namespace EZone.Business.Interface
{
    public interface IWalletService
    {
        Task<Wallet?> GetWalletAsync(string userId);
        Task<Wallet> CreateWalletAsync(string userId);
        Task<bool> DeductAmountAsync(string userId, decimal amount);
        Task<bool> AddAmountAsync(string userId, decimal amount);
        Task<decimal> GetBalanceAsync(string userId);
        Task<bool> HasSufficientBalanceAsync(string userId, decimal amount);
    }
}
