using EZone.Business.Interface;
using EZone.Repositories.Interface;
using EZone.Models;
using EZone.Data;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace EZone.Business.Service
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _orderRepository;
        private readonly IWalletService _walletService;
        private readonly AppDbContext _db;

        public OrderService(IOrderRepository orderRepository, IWalletService walletService, AppDbContext db)
        {
            _orderRepository = orderRepository;
            _walletService = walletService;
            _db = db;
        }

        public async Task<Order> PlaceOrderAsync(string userId, string paymentMethod)
        {
            // Calculate total from cart
            var cartItems = await _db.Carts
                .Include(c => c.Product)
                .Where(c => c.UserId == userId)
                .ToListAsync();

            if (!cartItems.Any())
                throw new Exception("Cart is empty");

            // Check stock availability
            foreach (var cartItem in cartItems)
            {
                if (cartItem.Product.Stock < cartItem.Quantity)
                    throw new Exception($"Insufficient stock for {cartItem.Product.Name}. Available: {cartItem.Product.Stock}, Requested: {cartItem.Quantity}");
            }

            var total = cartItems.Sum(c => c.Product.Price * c.Quantity);

            // Handle wallet payment
            if (paymentMethod.ToLower() == "wallet")
            {
                // Check if user has sufficient balance
                if (!await _walletService.HasSufficientBalanceAsync(userId, total))
                    throw new Exception("Insufficient wallet balance");

                // Deduct amount from wallet
                if (!await _walletService.DeductAmountAsync(userId, total))
                    throw new Exception("Failed to deduct amount from wallet");
            }

            // Create order items JSON
            var orderItems = cartItems.Select(c => new
            {
                ProductId = c.ProductId,
                ProductName = c.Product.Name,
                Quantity = c.Quantity,
                Price = c.Product.Price,
                TotalPrice = c.Product.Price * c.Quantity
            }).ToList();

            // Set order status based on payment method
            var orderStatus = paymentMethod.ToLower() == "wallet" ? "Success" : "Pending";

            var order = new Order
            {
                UserId = userId,
                PaymentMethod = paymentMethod,
                TotalAmount = total,
                Status = orderStatus,
                OrderItemsJson = JsonSerializer.Serialize(orderItems)
            };

            var savedOrder = await _orderRepository.AddOrderAsync(order);

            // Reduce product stock
            foreach (var cartItem in cartItems)
            {
                var product = await _db.Products.FindAsync(cartItem.ProductId);
                if (product != null)
                {
                    product.Stock -= cartItem.Quantity;
                    if (product.Stock < 0)
                        product.Stock = 0; // Prevent negative stock
                }
            }

            // Clear cart after order
            _db.Carts.RemoveRange(cartItems);
            await _db.SaveChangesAsync();

            return savedOrder;
        }

        public async Task<IEnumerable<Order>> GetOrdersAsync(string userId)
        {
            return await _orderRepository.GetOrdersByUserAsync(userId);
        }

        public async Task<Order?> GetOrderByIdAsync(int orderId)
        {
            return await _orderRepository.GetOrderByIdAsync(orderId);
        }

        public async Task<bool> CancelOrderAsync(int orderId, string userId)
        {
            var order = await _orderRepository.GetOrderByIdAsync(orderId);
            if (order == null || order.UserId != userId || order.Status != "Pending")
                return false;

            order.Status = "Cancelled";
            return await _orderRepository.UpdateOrderAsync(order);
        }

        public async Task<bool> DeleteOrderAsync(int orderId, string userId)
        {
            var order = await _orderRepository.GetOrderByIdAsync(orderId);
            if (order == null || order.UserId != userId || order.Status != "Pending")
                return false;

            return await _orderRepository.DeleteOrderAsync(orderId);
        }

       public async Task<bool> UpdateStatusAsync(int orderId, string status)
        {
            var order = await _orderRepository.GetOrderByIdAsync(orderId);
            if (order == null) return false;

            order.Status = status;
            return await _orderRepository.UpdateOrderAsync(order);
        }

        public async Task<IEnumerable<Order>> GetAllOrdersAsync()
        {
            return await _orderRepository.GetAllOrdersAsync();
        }
    }
}
