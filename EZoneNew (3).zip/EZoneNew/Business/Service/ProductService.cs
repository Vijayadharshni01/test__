using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EZone.Models;
using EZone.Business.Interface;
using EZone.Repositories.Interface;
using EZone.Repositories.Service;
namespace EZone.Business.Service
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository _repo;
        public ProductService(IProductRepository repo) => _repo = repo;


                public Task<Product> CreateAsync(Product p) {
                    return  _repo.AddAsync(p);
                }
                public Task<bool> DeleteAsync(int id) {
                     return _repo.DeleteAsync(id);
                }
                public Task<IEnumerable<Product>> GetAllAsync() {
                    return _repo.GetAllAsync();
                }
                public Task<Product> GetByIdAsync(int id){
                    return _repo.GetByIdAsync(id);
                }
                public Task<Product> UpdateAsync(Product p) {
                    return _repo.UpdateAsync(p);
                }
            }
}
