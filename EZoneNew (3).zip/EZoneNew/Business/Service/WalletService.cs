using EZone.Business.Interface;
using EZone.Models;
using EZone.Repositories.Interface;

namespace EZone.Business.Service
{
    public class WalletService : IWalletService
    {
        private readonly IWalletRepository _walletRepository;

        public WalletService(IWalletRepository walletRepository)
        {
            _walletRepository = walletRepository;
        }

        public async Task<Wallet?> GetWalletAsync(string userId)
        {
            return await _walletRepository.GetWalletByUserIdAsync(userId);
        }

        public async Task<Wallet> CreateWalletAsync(string userId)
        {
            return await _walletRepository.CreateWalletAsync(userId);
        }

        public async Task<bool> DeductAmountAsync(string userId, decimal amount)
        {
            if (amount <= 0)
                return false;

            return await _walletRepository.DeductAmountAsync(userId, amount);
        }

        public async Task<bool> AddAmountAsync(string userId, decimal amount)
        {
            if (amount <= 0)
                return false;

            return await _walletRepository.AddAmountAsync(userId, amount);
        }

        public async Task<decimal> GetBalanceAsync(string userId)
        {
            var wallet = await GetWalletAsync(userId);
            return wallet?.Balance ?? 0m;
        }

        public async Task<bool> HasSufficientBalanceAsync(string userId, decimal amount)
        {
            var balance = await GetBalanceAsync(userId);
            return balance >= amount;
        }
    }
}
