// using System;
// using System.Collections.Generic;
// using System.Linq;
// using System.Threading.Tasks;
// using Microsoft.AspNetCore.Mvc;
// using EZone.Business.Interface;
// using EZone.Business.Service;
// using EZone.Models;

// namespace EZone.Controllers
// {
//     [ApiController]
//     [Route("api/[controller]")]
//     public class AdminController : ControllerBase
//     {
//         private readonly IProductService _productService;
//         public AdminController(IProductService productService){
//              _productService = productService;
//         }

//         // In production protect endpoints with policy/role checks. For this demo, assume caller is admin.
//         //Add product by merchant
//         [HttpPost("product")]
//         public async Task<IActionResult> AddProduct([FromBody] Product p){
//             return Ok(await _productService.CreateAsync(p));
//         }

//         //Delete product by merchant
//         [HttpDelete("product/{id}")]
//         public async Task<IActionResult> DeleteProduct(int id){
//             return Ok(await _productService.DeleteAsync(id));
//         }
//     }
// }