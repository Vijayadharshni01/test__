using System;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using EZone.Business.Interface;
using EZone.Models;
using EZone.Security;
using EZone.Models.DTOs;


namespace EZone.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IUserService _userService;
        public AuthController(IUserService userService) => _userService = userService;

        // 🧍‍♀️ Register new user
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterDto dto)
        {
            try
            {
                if (dto == null)
                    return BadRequest(new { message = "Invalid registration data." });

                var user = new User
                {
                    Name = dto.Name,
                    Address = dto.Address,
                    PhoneNumber = dto.PhoneNumber,
                    Role = dto.Role,
                    Email = dto.Email,
                    UserName = dto.Username
                };

                var created = await _userService.RegisterAsync(user, dto.Password);
                if (created == null)
                    return BadRequest(new { message = "User registration failed." });

                return Ok(new
                {
                    message = "User registered successfully.",
                    created.Id,
                    created.UserName,
                    created.Email
                });
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred during registration.", error = ex.Message });
            }
        }

        // 🔐 Login
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginDto dto, [FromServices] JwtTokenGenerator tokenGen)
        {
            try
            {
                if (dto == null || string.IsNullOrEmpty(dto.Username) || string.IsNullOrEmpty(dto.Password))
                    return BadRequest(new { message = "Username and password are required." });

                var user = await _userService.AuthenticateAsync(dto.Username, dto.Password);
                if (user == null)
                    return Unauthorized(new { message = "Invalid username or password." });

                var token = tokenGen.GenerateToken(user);
                return Ok(new
                {
                    message = "Login successful.",
                    token,
                    user.Id,
                    user.UserName,
                    role = user.Role
                });
            }
            catch (UnauthorizedAccessException)
            {
                return Unauthorized(new { message = "Unauthorized access." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred during login.", error = ex.Message });
            }
        }

        // 👤 Get profile
        [Authorize]
        [HttpGet("profile")]
        public async Task<IActionResult> GetProfile([FromServices] IWalletService walletService)
        {
            try
            {
                var userIdClaim = User.FindFirst("id")?.Value;
                if (string.IsNullOrEmpty(userIdClaim))
                    return Unauthorized(new { message = "Invalid token" });

                var user = await _userService.GetProfileAsync(userIdClaim);
                if (user == null)
                    return NotFound(new { message = "User not found." });

                var walletBalance = await walletService.GetBalanceAsync(userIdClaim);

                return Ok(new
                {
                    user = new
                    {
                        user.Id,
                        user.Name,
                        user.Email,
                        user.PhoneNumber,
                        user.Address,
                        user.Role,
                        walletBalance
                    }
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while retrieving profile.", error = ex.Message });
            }
        }

        // 📝 Update profile
        [Authorize]
        [HttpPut("update-profile")]
        public async Task<IActionResult> UpdateProfile([FromBody] UpdateProfileDto dto)
{
    try
    {
        if (dto == null)
            return BadRequest(new { message = "Profile data cannot be empty." });

        var userIdClaim = User.FindFirst("id")?.Value;
        if (string.IsNullOrEmpty(userIdClaim))
            return Unauthorized(new { message = "Invalid token" });

        // 🔹 Don't parse to Guid; keep as string
        var updatedUser = new User
        {
            Id = userIdClaim, // ✅ string type
            Name = dto.Name,
            Address = dto.Address,
            PhoneNumber = dto.PhoneNumber,
            Email = dto.Email,
        };

        var result = await _userService.UpdateProfileAsync(updatedUser);

        if (result == null)
            return NotFound(new { message = "User not found." });

        return Ok(new
        {
            message = "Profile updated successfully.",
            user = new
            {
                result.Id,
                result.Name,
                result.Email,
                result.PhoneNumber,
                result.Address
            }
        });
    }
    catch (Exception ex)
    {
        return StatusCode(500, new { message = "An error occurred while updating profile.", error = ex.Message });
    }
}



    }
}
