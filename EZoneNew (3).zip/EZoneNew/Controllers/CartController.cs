using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using EZone.Business.Interface;
using EZone.Business.Service;

namespace EZone.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize] // Protects all routes in this controller
    public class CartController : ControllerBase
    {
        private readonly ICartService _cartService;

        public CartController(ICartService cartService)
        {
            _cartService = cartService;
        }

        // ✅ Get cart for logged-in user
        
        [HttpGet]
        public async Task<IActionResult> GetCart()
        {
            var userId = User.FindFirst("id")?.Value;
            return Ok(await _cartService.GetCartAsync(userId));
        }
        [Authorize]
        [HttpPost("add")]
        public async Task<IActionResult> AddToCart([FromQuery] int productId, [FromQuery] int qty = 1)
        {
            var userId = User.FindFirst("id")?.Value;
            var item = await _cartService.AddOrUpdateAsync(userId, productId, qty);
            return Ok(item);
        }
        [Authorize]
        [HttpDelete("{cartItemId}")]
        public async Task<IActionResult> Remove(int cartItemId)
        {
            var userId = User.FindFirst("id")?.Value;
            return Ok(await _cartService.RemoveAsync(cartItemId));
        }
    }
}
