using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EZone.Business.Interface;
using EZone.Data;

namespace EZone.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class OrderController : ControllerBase
    {
        private readonly IOrderService _orderService;
        private readonly AppDbContext _db;

        public OrderController(IOrderService orderService, AppDbContext db)
        {
            _orderService = orderService;
            _db = db;
        }

        // 🧾 Place new order (COD / Wallet)
        [HttpPost("place")]
        public async Task<IActionResult> PlaceOrder([FromQuery] string paymentMethod)
        {
            try
            {
                var userId = User.FindFirst("id")?.Value;
                if (string.IsNullOrEmpty(userId))
                    return Unauthorized(new { message = "Invalid or missing user token" });

                var order = await _orderService.PlaceOrderAsync(userId, paymentMethod);
                return Ok(new { message = "Order placed successfully", order });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { message = "Invalid operation", error = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error placing order", error = ex.Message });
            }
        }

        // 📦 Get all orders for logged-in user
        [HttpGet("my-orders")]
        public async Task<IActionResult> GetMyOrders()
        {
            try
            {
                var userId = User.FindFirst("id")?.Value;
                if (string.IsNullOrEmpty(userId))
                    return Unauthorized(new { message = "Invalid or missing user token" });

                var orders = await _orderService.GetOrdersAsync(userId);
                if (!orders.Any())
                    return NotFound(new { message = "No orders found for this user" });

                return Ok(orders);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error retrieving orders", error = ex.Message });
            }
        }

        // ❌ Delete/Cancel an order
        [HttpDelete("{orderId}")]
        public async Task<IActionResult> DeleteOrder(int orderId)
        {
            try
            {
                var userId = User.FindFirst("id")?.Value;
                if (string.IsNullOrEmpty(userId))
                    return Unauthorized(new { message = "Invalid or missing user token" });

                var result = await _orderService.DeleteOrderAsync(orderId, userId);

                if (!result)
                    return BadRequest(new { message = "Cannot delete this order — either it's not yours or already processed" });

                return Ok(new { message = "Order deleted successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error deleting order", error = ex.Message });
            }
        }
    }
}
