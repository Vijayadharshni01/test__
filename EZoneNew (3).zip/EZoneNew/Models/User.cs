using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;


namespace EZone.Models
{
    public class User : IdentityUser
    {
        [Required]
        public string? Name { get; set; }
        public string? Address { get; set; }
        public string? Role { get; set; }
        public decimal WalletBalance { get; set; } = 0; // optional if you track wallet in Wallet table
    }
}