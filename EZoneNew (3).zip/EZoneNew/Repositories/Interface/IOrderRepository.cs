using System.Collections.Generic;
using System.Threading.Tasks;
using EZone.Models;

namespace EZone.Repositories.Interface
{
    public interface IOrderRepository
    {
        Task<Order> AddOrderAsync(Order order);
        Task<IEnumerable<Order>> GetOrdersByUserAsync(string userId);
        Task<Order?> GetOrderByIdAsync(int orderId);
        Task<bool> UpdateOrderAsync(Order order);
        Task<bool> DeleteOrderAsync(int orderId);
        Task<IEnumerable<Order>> GetAllOrdersAsync();
    }
}
