using EZone.Data;
using EZone.Models;
using EZone.Repositories.Interface;
using Microsoft.EntityFrameworkCore;

namespace EZone.Repositories.Service
{
    public class WalletRepository : IWalletRepository
    {
        private readonly AppDbContext _db;

        public WalletRepository(AppDbContext db)
        {
            _db = db;
        }

        public async Task<Wallet?> GetWalletByUserIdAsync(string userId)
        {
            return await _db.Wallets.FirstOrDefaultAsync(w => w.UserId == userId);
        }

        public async Task<Wallet> CreateWalletAsync(string userId)
        {
            var wallet = new Wallet
            {
                UserId = userId,
                Balance = 0m
            };
            
            _db.Wallets.Add(wallet);
            await _db.SaveChangesAsync();
            return wallet;
        }

        public async Task<bool> UpdateWalletAsync(Wallet wallet)
        {
            _db.Wallets.Update(wallet);
            return await _db.SaveChangesAsync() > 0;
        }

        public async Task<bool> DeductAmountAsync(string userId, decimal amount)
        {
            var wallet = await GetWalletByUserIdAsync(userId);
            if (wallet == null || wallet.Balance < amount)
                return false;

            wallet.Balance -= amount;
            return await UpdateWalletAsync(wallet);
        }

        public async Task<bool> AddAmountAsync(string userId, decimal amount)
        {
            var wallet = await GetWalletByUserIdAsync(userId);
            if (wallet == null)
            {
                wallet = await CreateWalletAsync(userId);
            }

            wallet.Balance += amount;
            return await UpdateWalletAsync(wallet);
        }
    }
}
