using NUnit.Framework;
using Moq;
using EZone.Controllers;
using EZone.Business.Interface;
using EZone.Models;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;

namespace EZoneNew.Tests.Controllers
{
    [TestFixture]
    public class CartControllerTests
    {
        private Mock<ICartService> _mockCartService;
        private CartController _controller;

        [SetUp]
        public void Setup()
        {
            _mockCartService = new Mock<ICartService>();
            _controller = new CartController(_mockCartService.Object);
            
            // Setup user claims
            var claims = new List<Claim>
            {
                new Claim("id", "user123")
            };
            var identity = new ClaimsIdentity(claims, "TestAuthType");
            var claimsPrincipal = new ClaimsPrincipal(identity);
            
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext
                {
                    User = claimsPrincipal
                }
            };
        }

        [Test]
        public async Task GetCart_WhenUserIsAuthenticated_ReturnsCartItems()
        {
            // Arrange
            var userId = "user123";
            var cartItems = new List<Cart>
            {
                new Cart { Id = 1, UserId = userId, ProductId = 1, Quantity = 2 },
                new Cart { Id = 2, UserId = userId, ProductId = 2, Quantity = 1 }
            };
            _mockCartService.Setup(x => x.GetCartAsync(userId))
                .ReturnsAsync(cartItems);

            // Act
            var result = await _controller.GetCart();

            // Assert
            Assert.That(result, Is.InstanceOf<OkObjectResult>());
            var okResult = result as OkObjectResult;
            Assert.That(okResult.Value, Is.EqualTo(cartItems));
        }

        [Test]
        public async Task GetCart_WhenUserIsNotAuthenticated_ReturnsUnauthorized()
        {
            // Arrange
            _controller.ControllerContext.HttpContext.User = new ClaimsPrincipal();

            // Act
            var result = await _controller.GetCart();

            // Assert
            Assert.That(result, Is.InstanceOf<UnauthorizedObjectResult>());
        }

        [Test]
        public async Task AddToCart_WhenValidRequest_ReturnsCartItem()
        {
            // Arrange
            var userId = "user123";
            var productId = 1;
            var quantity = 3;
            var cartItem = new Cart 
            { 
                Id = 1, 
                UserId = userId, 
                ProductId = productId, 
                Quantity = quantity 
            };
            _mockCartService.Setup(x => x.AddOrUpdateAsync(userId, productId, quantity))
                .ReturnsAsync(cartItem);

            // Act
            var result = await _controller.AddToCart(productId, quantity);

            // Assert
            Assert.That(result, Is.InstanceOf<OkObjectResult>());
            var okResult = result as OkObjectResult;
            Assert.That(okResult.Value, Is.EqualTo(cartItem));
        }

        [Test]
        public async Task AddToCart_WhenUserIsNotAuthenticated_ReturnsUnauthorized()
        {
            // Arrange
            _controller.ControllerContext.HttpContext.User = new ClaimsPrincipal();
            var productId = 1;
            var quantity = 1;

            // Act
            var result = await _controller.AddToCart(productId, quantity);

            // Assert
            Assert.That(result, Is.InstanceOf<UnauthorizedObjectResult>());
        }

        [Test]
        public async Task AddToCart_WithDefaultQuantity_UsesDefaultValue()
        {
            // Arrange
            var userId = "user123";
            var productId = 1;
            var cartItem = new Cart 
            { 
                Id = 1, 
                UserId = userId, 
                ProductId = productId, 
                Quantity = 1 
            };
            _mockCartService.Setup(x => x.AddOrUpdateAsync(userId, productId, 1))
                .ReturnsAsync(cartItem);

            // Act
            var result = await _controller.AddToCart(productId);

            // Assert
            Assert.That(result, Is.InstanceOf<OkObjectResult>());
            _mockCartService.Verify(x => x.AddOrUpdateAsync(userId, productId, 1), Times.Once);
        }

        [Test]
        public async Task Remove_WhenItemExists_ReturnsSuccess()
        {
            // Arrange
            var cartItemId = 1;
            _mockCartService.Setup(x => x.RemoveAsync(cartItemId))
                .ReturnsAsync(true);

            // Act
            var result = await _controller.Remove(cartItemId);

            // Assert
            Assert.That(result, Is.InstanceOf<OkObjectResult>());
            var okResult = result as OkObjectResult;
            var response = okResult.Value as dynamic;
            Assert.That(response.message, Does.Contain("Item removed from cart"));
        }

        [Test]
        public async Task Remove_WhenItemDoesNotExist_ReturnsBadRequest()
        {
            // Arrange
            var cartItemId = 999;
            _mockCartService.Setup(x => x.RemoveAsync(cartItemId))
                .ReturnsAsync(false);

            // Act
            var result = await _controller.Remove(cartItemId);

            // Assert
            Assert.That(result, Is.InstanceOf<BadRequestObjectResult>());
            var badRequestResult = result as BadRequestObjectResult;
            var response = badRequestResult.Value as dynamic;
            Assert.That(response.message, Does.Contain("Item not found"));
        }

        [Test]
        public async Task Remove_WhenUserIsNotAuthenticated_ReturnsUnauthorized()
        {
            // Arrange
            _controller.ControllerContext.HttpContext.User = new ClaimsPrincipal();
            var cartItemId = 1;

            // Act
            var result = await _controller.Remove(cartItemId);

            // Assert
            Assert.That(result, Is.InstanceOf<UnauthorizedObjectResult>());
        }
    }
}
