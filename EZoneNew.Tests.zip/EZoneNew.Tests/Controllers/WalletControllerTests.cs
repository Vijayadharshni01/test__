using EZone.Business.Interface;
using EZone.Controllers;
using EZone.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System.Security.Claims;

namespace EZoneNew.Tests.Controllers
{
    [TestFixture]
    public class WalletControllerTests
    {
        private Mock<IWalletService> _mockWalletService;
        private WalletController _controller;

        [SetUp]
        public void Setup()
        {
            _mockWalletService = new Mock<IWalletService>();
            _controller = new WalletController(_mockWalletService.Object);
        }

        [Test]
        public async Task GetBalance_WithValidUser_ReturnsOkWithBalance()
        {
            // Arrange
            var userId = "user123";
            var balance = 100.50m;
            
            var claims = new List<Claim>
            {
                new Claim("id", userId)
            };
            var identity = new ClaimsIdentity(claims, "test");
            var principal = new ClaimsPrincipal(identity);
            
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext { User = principal }
            };

            _mockWalletService.Setup(s => s.GetBalanceAsync(userId)).ReturnsAsync(balance);

            // Act
            var result = await _controller.GetBalance();

            // Assert
            Assert.That(result, Is.InstanceOf<OkObjectResult>());
            var okResult = result as OkObjectResult;
            Assert.That(okResult!.Value, Is.Not.Null);
        }

        [Test]
        public async Task GetBalance_WithInvalidUser_ReturnsUnauthorized()
        {
            // Arrange
            var claims = new List<Claim>();
            var identity = new ClaimsIdentity(claims, "test");
            var principal = new ClaimsPrincipal(identity);
            
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext { User = principal }
            };

            // Act
            var result = await _controller.GetBalance();

            // Assert
            Assert.That(result, Is.InstanceOf<UnauthorizedObjectResult>());
        }

        [Test]
        public async Task GetWalletDetails_WithValidUser_ReturnsOkWithWallet()
        {
            // Arrange
            var userId = "user123";
            var wallet = new Wallet { UserId = userId, Balance = 100.50m };
            
            var claims = new List<Claim>
            {
                new Claim("id", userId)
            };
            var identity = new ClaimsIdentity(claims, "test");
            var principal = new ClaimsPrincipal(identity);
            
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext { User = principal }
            };

            _mockWalletService.Setup(s => s.GetWalletAsync(userId)).ReturnsAsync(wallet);

            // Act
            var result = await _controller.GetWallet();

            // Assert
            Assert.That(result, Is.InstanceOf<OkObjectResult>());
            var okResult = result as OkObjectResult;
            Assert.That(okResult!.Value, Is.Not.Null);
        }

        [Test]
        public async Task AddMoney_WithValidAmount_ReturnsOkWithNewBalance()
        {
            // Arrange
            var userId = "user123";
            var amount = 50.00m;
            var newBalance = 150.50m;
            
            var claims = new List<Claim>
            {
                new Claim("id", userId)
            };
            var identity = new ClaimsIdentity(claims, "test");
            var principal = new ClaimsPrincipal(identity);
            
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext { User = principal }
            };

            _mockWalletService.Setup(s => s.AddAmountAsync(userId, amount)).ReturnsAsync(true);
            _mockWalletService.Setup(s => s.GetBalanceAsync(userId)).ReturnsAsync(newBalance);

            // Act
            var result = await _controller.AddMoney(amount);

            // Assert
            Assert.That(result, Is.InstanceOf<OkObjectResult>());
            var okResult = result as OkObjectResult;
            Assert.That(okResult!.Value, Is.Not.Null);
        }

        [Test]
        public async Task AddMoney_WithNegativeAmount_ReturnsBadRequest()
        {
            // Arrange
            var userId = "user123";
            var amount = -10.00m;
            
            var claims = new List<Claim>
            {
                new Claim("id", userId)
            };
            var identity = new ClaimsIdentity(claims, "test");
            var principal = new ClaimsPrincipal(identity);
            
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext { User = principal }
            };

            _mockWalletService.Setup(s => s.AddAmountAsync(userId, amount))
                .ThrowsAsync(new ArgumentException("Amount must be positive"));

            // Act
            var result = await _controller.AddMoney(amount);

            // Assert
            Assert.That(result, Is.InstanceOf<BadRequestObjectResult>());
        }

        [Test]
        public async Task AddMoney_WithInvalidUser_ReturnsUnauthorized()
        {
            // Arrange
            var amount = 50.00m;
            var claims = new List<Claim>();
            var identity = new ClaimsIdentity(claims, "test");
            var principal = new ClaimsPrincipal(identity);
            
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext { User = principal }
            };

            // Act
            var result = await _controller.AddMoney(amount);

            // Assert
            Assert.That(result, Is.InstanceOf<UnauthorizedObjectResult>());
        }

        [Test]
        public async Task AddMoney_WithServiceException_ReturnsInternalServerError()
        {
            // Arrange
            var userId = "user123";
            var amount = 50.00m;
            
            var claims = new List<Claim>
            {
                new Claim("id", userId)
            };
            var identity = new ClaimsIdentity(claims, "test");
            var principal = new ClaimsPrincipal(identity);
            
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext { User = principal }
            };

            _mockWalletService.Setup(s => s.AddAmountAsync(userId, amount))
                .ThrowsAsync(new Exception("Database error"));

            // Act
            var result = await _controller.AddMoney(amount);

            // Assert
            Assert.That(result, Is.InstanceOf<ObjectResult>());
            var objectResult = result as ObjectResult;
            Assert.That(objectResult!.StatusCode, Is.EqualTo(500));
        }
    }
}