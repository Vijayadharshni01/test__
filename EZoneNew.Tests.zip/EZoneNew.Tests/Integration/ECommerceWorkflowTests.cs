using NUnit.Framework;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using EZone.Data;
using EZone.Models;
using Microsoft.EntityFrameworkCore;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Identity;
using EZone.Security;

namespace EZoneNew.Tests.Integration
{
    [TestFixture]
    public class ECommerceWorkflowTests
    {
        private WebApplicationFactory<Program> _factory;
        private HttpClient _client;
        private AppDbContext _context;
        private string _authToken;

        [SetUp]
        public async Task Setup()
        {
            _factory = new WebApplicationFactory<Program>();
            _client = _factory.CreateClient();

            // Setup in-memory database
            var scope = _factory.Services.CreateScope();
            _context = scope.ServiceProvider.GetRequiredService<AppDbContext>();
            
            // Clear existing data
            _context.Database.EnsureDeleted();
            _context.Database.EnsureCreated();

            // Seed test data
            await SeedTestData();
            
            // Register and login user
            await RegisterAndLoginUser();
        }

        [TearDown]
        public void TearDown()
        {
            _context?.Dispose();
            _client?.Dispose();
            _factory?.Dispose();
        }

        private async Task SeedTestData()
        {
            var products = new List<Product>
            {
                new Product { Name = "Laptop", Description = "High-performance laptop", Price = 1000.00m, Stock = 10 },
                new Product { Name = "Phone", Description = "Smartphone", Price = 500.00m, Stock = 20 },
                new Product { Name = "Headphones", Description = "Wireless headphones", Price = 150.00m, Stock = 15 }
            };

            _context.Products.AddRange(products);
            await _context.SaveChangesAsync();
        }

        private async Task RegisterAndLoginUser()
        {
            // Register user
            var registerData = new
            {
                name = "Test User",
                address = "123 Test St",
                phoneNumber = "1234567890",
                email = "test@example.com",
                username = "testuser",
                password = "Test123!",
                role = "Customer"
            };

            var registerJson = JsonSerializer.Serialize(registerData);
            var registerContent = new StringContent(registerJson, Encoding.UTF8, "application/json");
            var registerResponse = await _client.PostAsync("/api/auth/register", registerContent);
            Assert.That(registerResponse.IsSuccessStatusCode, Is.True);

            // Login user
            var loginData = new
            {
                username = "testuser",
                password = "Test123!"
            };

            var loginJson = JsonSerializer.Serialize(loginData);
            var loginContent = new StringContent(loginJson, Encoding.UTF8, "application/json");
            var loginResponse = await _client.PostAsync("/api/auth/login", loginContent);
            Assert.That(loginResponse.IsSuccessStatusCode, Is.True);

            var loginResult = await loginResponse.Content.ReadAsStringAsync();
            var loginResponseObj = JsonSerializer.Deserialize<JsonElement>(loginResult);
            _authToken = loginResponseObj.GetProperty("token").GetString();
            
            // Set authorization header
            _client.DefaultRequestHeaders.Authorization = 
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _authToken);
        }

        [Test]
        public async Task CompleteShoppingWorkflow_WithWalletPayment_Success()
        {
            // Step 1: Add money to wallet
            var addMoneyResponse = await _client.PostAsync("/api/wallet/add?amount=2000", null);
            Assert.That(addMoneyResponse.IsSuccessStatusCode, Is.True);

            // Step 2: Get products
            var productsResponse = await _client.GetAsync("/api/products");
            Assert.That(productsResponse.IsSuccessStatusCode, Is.True);
            
            var productsJson = await productsResponse.Content.ReadAsStringAsync();
            var products = JsonSerializer.Deserialize<JsonElement[]>(productsJson);
            Assert.That(products.Length, Is.GreaterThan(0));

            // Step 3: Add items to cart
            var addToCartResponse = await _client.PostAsync("/api/cart/add?productId=1&qty=2", null);
            Assert.That(addToCartResponse.IsSuccessStatusCode, Is.True);

            addToCartResponse = await _client.PostAsync("/api/cart/add?productId=2&qty=1", null);
            Assert.That(addToCartResponse.IsSuccessStatusCode, Is.True);

            // Step 4: Get cart
            var cartResponse = await _client.GetAsync("/api/cart");
            Assert.That(cartResponse.IsSuccessStatusCode, Is.True);
            
            var cartJson = await cartResponse.Content.ReadAsStringAsync();
            var cartItems = JsonSerializer.Deserialize<JsonElement[]>(cartJson);
            Assert.That(cartItems.Length, Is.EqualTo(2));

            // Step 5: Place order with wallet payment
            var orderResponse = await _client.PostAsync("/api/order/place?paymentMethod=wallet", null);
            Assert.That(orderResponse.IsSuccessStatusCode, Is.True);
            
            var orderJson = await orderResponse.Content.ReadAsStringAsync();
            var orderResult = JsonSerializer.Deserialize<JsonElement>(orderJson);
            Assert.That(orderResult.GetProperty("order").GetProperty("status").GetString(), Is.EqualTo("Success"));

            // Step 6: Verify cart is empty
            var emptyCartResponse = await _client.GetAsync("/api/cart");
            Assert.That(emptyCartResponse.IsSuccessStatusCode, Is.True);
            
            var emptyCartJson = await emptyCartResponse.Content.ReadAsStringAsync();
            var emptyCartItems = JsonSerializer.Deserialize<JsonElement[]>(emptyCartJson);
            Assert.That(emptyCartItems.Length, Is.EqualTo(0));

            // Step 7: Check wallet balance reduced
            var balanceResponse = await _client.GetAsync("/api/wallet/balance");
            Assert.That(balanceResponse.IsSuccessStatusCode, Is.True);
            
            var balanceJson = await balanceResponse.Content.ReadAsStringAsync();
            var balanceResult = JsonSerializer.Deserialize<JsonElement>(balanceJson);
            var balance = balanceResult.GetProperty("balance").GetDecimal();
            Assert.That(balance, Is.LessThan(2000)); // Should be less than initial amount

            // Step 8: Get order history
            var ordersResponse = await _client.GetAsync("/api/order/my-orders");
            Assert.That(ordersResponse.IsSuccessStatusCode, Is.True);
            
            var ordersJson = await ordersResponse.Content.ReadAsStringAsync();
            var orders = JsonSerializer.Deserialize<JsonElement[]>(ordersJson);
            Assert.That(orders.Length, Is.EqualTo(1));
            Assert.That(orders[0].GetProperty("status").GetString(), Is.EqualTo("Success"));
        }

        [Test]
        public async Task CompleteShoppingWorkflow_WithCreditCardPayment_Success()
        {
            // Step 1: Add items to cart
            var addToCartResponse = await _client.PostAsync("/api/cart/add?productId=1&qty=1", null);
            Assert.That(addToCartResponse.IsSuccessStatusCode, Is.True);

            // Step 2: Place order with credit card payment
            var orderResponse = await _client.PostAsync("/api/order/place?paymentMethod=creditcard", null);
            Assert.That(orderResponse.IsSuccessStatusCode, Is.True);
            
            var orderJson = await orderResponse.Content.ReadAsStringAsync();
            var orderResult = JsonSerializer.Deserialize<JsonElement>(orderJson);
            Assert.That(orderResult.GetProperty("order").GetProperty("status").GetString(), Is.EqualTo("Pending"));

            // Step 3: Verify order can be deleted (since it's pending)
            var orderId = orderResult.GetProperty("order").GetProperty("id").GetInt32();
            var deleteResponse = await _client.DeleteAsync($"/api/order/{orderId}");
            Assert.That(deleteResponse.IsSuccessStatusCode, Is.True);
        }

        [Test]
        public async Task InsufficientWalletBalance_ShouldFail()
        {
            // Step 1: Add small amount to wallet
            var addMoneyResponse = await _client.PostAsync("/api/wallet/add?amount=100", null);
            Assert.That(addMoneyResponse.IsSuccessStatusCode, Is.True);

            // Step 2: Add expensive item to cart
            var addToCartResponse = await _client.PostAsync("/api/cart/add?productId=1&qty=1", null);
            Assert.That(addToCartResponse.IsSuccessStatusCode, Is.True);

            // Step 3: Try to place order with wallet payment (should fail)
            var orderResponse = await _client.PostAsync("/api/order/place?paymentMethod=wallet", null);
            Assert.That(orderResponse.IsSuccessStatusCode, Is.False);
            
            var orderJson = await orderResponse.Content.ReadAsStringAsync();
            var orderResult = JsonSerializer.Deserialize<JsonElement>(orderJson);
            Assert.That(orderResult.GetProperty("message").GetString(), Does.Contain("Insufficient wallet balance"));
        }

        [Test]
        public async Task StockReduction_AfterOrder_ShouldWork()
        {
            // Step 1: Get initial stock
            var productsResponse = await _client.GetAsync("/api/products");
            var productsJson = await productsResponse.Content.ReadAsStringAsync();
            var products = JsonSerializer.Deserialize<JsonElement[]>(productsJson);
            var initialStock = products[0].GetProperty("stock").GetInt32();

            // Step 2: Add money to wallet
            await _client.PostAsync("/api/wallet/add?amount=2000", null);

            // Step 3: Add item to cart
            await _client.PostAsync("/api/cart/add?productId=1&qty=3", null);

            // Step 4: Place order
            await _client.PostAsync("/api/order/place?paymentMethod=wallet", null);

            // Step 5: Verify stock was reduced
            var updatedProductsResponse = await _client.GetAsync("/api/products");
            var updatedProductsJson = await updatedProductsResponse.Content.ReadAsStringAsync();
            var updatedProducts = JsonSerializer.Deserialize<JsonElement[]>(updatedProductsJson);
            var updatedStock = updatedProducts[0].GetProperty("stock").GetInt32();

            Assert.That(updatedStock, Is.EqualTo(initialStock - 3));
        }

        [Test]
        public async Task InsufficientStock_ShouldFail()
        {
            // Step 1: Add money to wallet
            await _client.PostAsync("/api/wallet/add?amount=20000", null);

            // Step 2: Try to add more items than available in stock
            var addToCartResponse = await _client.PostAsync("/api/cart/add?productId=1&qty=15", null);
            Assert.That(addToCartResponse.IsSuccessStatusCode, Is.True);

            // Step 3: Try to place order (should fail due to insufficient stock)
            var orderResponse = await _client.PostAsync("/api/order/place?paymentMethod=wallet", null);
            Assert.That(orderResponse.IsSuccessStatusCode, Is.False);
            
            var orderJson = await orderResponse.Content.ReadAsStringAsync();
            var orderResult = JsonSerializer.Deserialize<JsonElement>(orderJson);
            Assert.That(orderResult.GetProperty("message").GetString(), Does.Contain("Insufficient stock"));
        }
    }
}
