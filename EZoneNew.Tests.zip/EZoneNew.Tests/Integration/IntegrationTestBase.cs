using NUnit.Framework;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using EZone.Data;
using Microsoft.EntityFrameworkCore;

namespace EZoneNew.Tests.Integration
{
    [TestFixture]
    public class IntegrationTestBase
    {
        protected WebApplicationFactory<Program> Factory { get; private set; }
        protected HttpClient Client { get; private set; }
        protected AppDbContext Context { get; private set; }

        [SetUp]
        public virtual void Setup()
        {
            Factory = new WebApplicationFactory<Program>();
            Client = Factory.CreateClient();

            // Setup in-memory database for testing
            var scope = Factory.Services.CreateScope();
            Context = scope.ServiceProvider.GetRequiredService<AppDbContext>();
            
            // Clear and recreate database
            Context.Database.EnsureDeleted();
            Context.Database.EnsureCreated();
        }

        [TearDown]
        public virtual void TearDown()
        {
            Context?.Dispose();
            Client?.Dispose();
            Factory?.Dispose();
        }

        protected async Task<string> RegisterAndLoginUser(string username = "testuser", string password = "Test123!")
        {
            // Register user
            var registerData = new
            {
                name = "Test User",
                address = "123 Test St",
                phoneNumber = "1234567890",
                email = $"{username}@example.com",
                username = username,
                password = password,
                role = "Customer"
            };

            var registerJson = System.Text.Json.JsonSerializer.Serialize(registerData);
            var registerContent = new StringContent(registerJson, System.Text.Encoding.UTF8, "application/json");
            var registerResponse = await Client.PostAsync("/api/auth/register", registerContent);
            Assert.That(registerResponse.IsSuccessStatusCode, Is.True);

            // Login user
            var loginData = new
            {
                username = username,
                password = password
            };

            var loginJson = System.Text.Json.JsonSerializer.Serialize(loginData);
            var loginContent = new StringContent(loginJson, System.Text.Encoding.UTF8, "application/json");
            var loginResponse = await Client.PostAsync("/api/auth/login", loginContent);
            Assert.That(loginResponse.IsSuccessStatusCode, Is.True);

            var loginResult = await loginResponse.Content.ReadAsStringAsync();
            var loginResponseObj = System.Text.Json.JsonSerializer.Deserialize<System.Text.Json.JsonElement>(loginResult);
            var token = loginResponseObj.GetProperty("token").GetString();
            
            // Set authorization header
            Client.DefaultRequestHeaders.Authorization = 
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

            return token;
        }

        protected async Task SeedTestProducts()
        {
            var products = new List<EZone.Models.Product>
            {
                new EZone.Models.Product { Name = "Laptop", Description = "High-performance laptop", Price = 1000.00m, Stock = 10 },
                new EZone.Models.Product { Name = "Phone", Description = "Smartphone", Price = 500.00m, Stock = 20 },
                new EZone.Models.Product { Name = "Headphones", Description = "Wireless headphones", Price = 150.00m, Stock = 15 }
            };

            Context.Products.AddRange(products);
            await Context.SaveChangesAsync();
        }
    }
}
