using NUnit.Framework;
using EZone.Models;

namespace EZoneNew.Tests.Models
{
    [TestFixture]
    public class CartTests
    {
        [Test]
        public void Cart_ShouldHaveDefaultQuantity()
        {
            // Arrange & Act
            var cart = new Cart();

            // Assert
            Assert.That(cart.Quantity, Is.EqualTo(1));
        }

        [Test]
        public void Cart_ShouldCalculateTotalPriceCorrectly()
        {
            // Arrange
            var product = new Product
            {
                Price = 50.00m
            };
            var cart = new Cart
            {
                Product = product,
                Quantity = 3
            };

            // Act
            var totalPrice = cart.TotalPrice;

            // Assert
            Assert.That(totalPrice, Is.EqualTo(150.00m));
        }

        [Test]
        public void Cart_ShouldReturnZeroWhenProductIsNull()
        {
            // Arrange
            var cart = new Cart
            {
                Product = null,
                Quantity = 5
            };

            // Act
            var totalPrice = cart.TotalPrice;

            // Assert
            Assert.That(totalPrice, Is.EqualTo(0));
        }

        [Test]
        public void Cart_ShouldAllowSettingProperties()
        {
            // Arrange
            var product = new Product { Name = "Test Product" };
            var cart = new Cart
            {
                UserId = "user123",
                ProductId = 1,
                Product = product,
                Quantity = 2
            };

            // Assert
            Assert.That(cart.UserId, Is.EqualTo("user123"));
            Assert.That(cart.ProductId, Is.EqualTo(1));
            Assert.That(cart.Product, Is.EqualTo(product));
            Assert.That(cart.Quantity, Is.EqualTo(2));
        }
    }
}
