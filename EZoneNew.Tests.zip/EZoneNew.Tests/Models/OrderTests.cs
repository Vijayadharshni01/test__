using NUnit.Framework;
using EZone.Models;

namespace EZoneNew.Tests.Models
{
    [TestFixture]
    public class OrderTests
    {
        [Test]
        public void Order_ShouldHaveDefaultStatus()
        {
            // Arrange & Act
            var order = new Order();

            // Assert
            Assert.That(order.Status, Is.EqualTo("Placed"));
        }

        [Test]
        public void Order_ShouldHaveDefaultCreatedAt()
        {
            // Arrange & Act
            var order = new Order();
            var now = DateTime.UtcNow;

            // Assert
            Assert.That(order.CreatedAt, Is.LessThanOrEqualTo(now));
            Assert.That(order.CreatedAt, Is.GreaterThan(now.AddMinutes(-1)));
        }

        [Test]
        public void Order_ShouldAllowSettingProperties()
        {
            // Arrange
            var order = new Order
            {
                UserId = "user123",
                TotalAmount = 299.99m,
                PaymentMethod = "creditcard",
                Status = "Success",
                OrderItemsJson = "[{\"ProductId\":1,\"Quantity\":2}]"
            };

            // Assert
            Assert.That(order.UserId, Is.EqualTo("user123"));
            Assert.That(order.TotalAmount, Is.EqualTo(299.99m));
            Assert.That(order.PaymentMethod, Is.EqualTo("creditcard"));
            Assert.That(order.Status, Is.EqualTo("Success"));
            Assert.That(order.OrderItemsJson, Is.EqualTo("[{\"ProductId\":1,\"Quantity\":2}]"));
        }

        [Test]
        public void Order_ShouldAllowDifferentPaymentMethods()
        {
            // Arrange & Act
            var creditCardOrder = new Order { PaymentMethod = "creditcard" };
            var walletOrder = new Order { PaymentMethod = "wallet" };
            var cashOrder = new Order { PaymentMethod = "cash" };

            // Assert
            Assert.That(creditCardOrder.PaymentMethod, Is.EqualTo("creditcard"));
            Assert.That(walletOrder.PaymentMethod, Is.EqualTo("wallet"));
            Assert.That(cashOrder.PaymentMethod, Is.EqualTo("cash"));
        }

        [Test]
        public void Order_ShouldAllowDifferentStatuses()
        {
            // Arrange & Act
            var placedOrder = new Order { Status = "Placed" };
            var successOrder = new Order { Status = "Success" };
            var cancelledOrder = new Order { Status = "Cancelled" };

            // Assert
            Assert.That(placedOrder.Status, Is.EqualTo("Placed"));
            Assert.That(successOrder.Status, Is.EqualTo("Success"));
            Assert.That(cancelledOrder.Status, Is.EqualTo("Cancelled"));
        }
    }
}
