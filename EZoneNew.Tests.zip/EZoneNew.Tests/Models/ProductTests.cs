using NUnit.Framework;
using EZone.Models;

namespace EZoneNew.Tests.Models
{
    [TestFixture]
    public class ProductTests
    {
        [Test]
        public void Product_ShouldHaveDefaultStock()
        {
            // Arrange & Act
            var product = new Product();

            // Assert
            Assert.That(product.Stock, Is.EqualTo(0));
        }

        [Test]
        public void Product_ShouldAllowSettingProperties()
        {
            // Arrange
            var product = new Product
            {
                Name = "Test Product",
                Description = "Test Description",
                Price = 99.99m,
                Stock = 10,
                ImageUrl = "https://example.com/image.jpg"
            };

            // Assert
            Assert.That(product.Name, Is.EqualTo("Test Product"));
            Assert.That(product.Description, Is.EqualTo("Test Description"));
            Assert.That(product.Price, Is.EqualTo(99.99m));
            Assert.That(product.Stock, Is.EqualTo(10));
            Assert.That(product.ImageUrl, Is.EqualTo("https://example.com/image.jpg"));
        }

        [Test]
        public void Product_ShouldAllowNullImageUrl()
        {
            // Arrange & Act
            var product = new Product
            {
                Name = "Test Product",
                ImageUrl = null
            };

            // Assert
            Assert.That(product.ImageUrl, Is.Null);
        }

        [Test]
        public void Product_ShouldHandleNegativeStock()
        {
            // Arrange & Act
            var product = new Product
            {
                Stock = -5
            };

            // Assert
            Assert.That(product.Stock, Is.EqualTo(-5));
        }

        [Test]
        public void Product_ShouldHandleZeroPrice()
        {
            // Arrange & Act
            var product = new Product
            {
                Price = 0m
            };

            // Assert
            Assert.That(product.Price, Is.EqualTo(0m));
        }
    }
}
