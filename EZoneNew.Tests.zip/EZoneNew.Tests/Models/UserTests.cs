using NUnit.Framework;
using EZone.Models;
using Microsoft.AspNetCore.Identity;

namespace EZoneNew.Tests.Models
{
    [TestFixture]
    public class UserTests
    {
        [Test]
        public void User_ShouldInheritFromIdentityUser()
        {
            // Arrange & Act
            var user = new User();

            // Assert
            Assert.That(user, Is.InstanceOf<IdentityUser>());
        }

        [Test]
        public void User_ShouldHaveDefaultWalletBalance()
        {
            // Arrange & Act
            var user = new User();

            // Assert
            Assert.That(user.WalletBalance, Is.EqualTo(0));
        }

        [Test]
        public void User_ShouldAllowSettingProperties()
        {
            // Arrange
            var user = new User
            {
                Name = "Test User",
                Address = "123 Test St",
                Email = "test@example.com",
                Role = "Customer",
                WalletBalance = 100.50m
            };

            // Assert
            Assert.That(user.Name, Is.EqualTo("Test User"));
            Assert.That(user.Address, Is.EqualTo("123 Test St"));
            Assert.That(user.Email, Is.EqualTo("test@example.com"));
            Assert.That(user.Role, Is.EqualTo("Customer"));
            Assert.That(user.WalletBalance, Is.EqualTo(100.50m));
        }

        [Test]
        public void User_ShouldAllowNullProperties()
        {
            // Arrange & Act
            var user = new User
            {
                Name = null,
                Address = null,
                Role = null
            };

            // Assert
            Assert.That(user.Name, Is.Null);
            Assert.That(user.Address, Is.Null);
            Assert.That(user.Role, Is.Null);
        }
    }
}
