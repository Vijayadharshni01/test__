using NUnit.Framework;
using EZone.Models;

namespace EZoneNew.Tests.Models
{
    [TestFixture]
    public class WalletTests
    {
        [Test]
        public void Wallet_ShouldHaveDefaultBalance()
        {
            // Arrange & Act
            var wallet = new Wallet();

            // Assert
            Assert.That(wallet.Balance, Is.EqualTo(0m));
        }

        [Test]
        public void Wallet_ShouldAllowSettingProperties()
        {
            // Arrange
            var wallet = new Wallet
            {
                UserId = "user123",
                Balance = 500.75m
            };

            // Assert
            Assert.That(wallet.UserId, Is.EqualTo("user123"));
            Assert.That(wallet.Balance, Is.EqualTo(500.75m));
        }

        [Test]
        public void Wallet_ShouldHandleNegativeBalance()
        {
            // Arrange & Act
            var wallet = new Wallet
            {
                Balance = -100.00m
            };

            // Assert
            Assert.That(wallet.Balance, Is.EqualTo(-100.00m));
        }

        [Test]
        public void Wallet_ShouldHandleZeroBalance()
        {
            // Arrange & Act
            var wallet = new Wallet
            {
                Balance = 0m
            };

            // Assert
            Assert.That(wallet.Balance, Is.EqualTo(0m));
        }

        [Test]
        public void Wallet_ShouldHandleLargeBalance()
        {
            // Arrange & Act
            var wallet = new Wallet
            {
                Balance = 999999.99m
            };

            // Assert
            Assert.That(wallet.Balance, Is.EqualTo(999999.99m));
        }
    }
}
