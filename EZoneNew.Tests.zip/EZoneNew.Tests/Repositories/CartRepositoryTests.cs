using NUnit.Framework;
using EZone.Data;
using EZone.Models;
using EZone.Repositories.Service;
using Microsoft.EntityFrameworkCore;

namespace EZoneNew.Tests.Repositories
{
    [TestFixture]
    public class CartRepositoryTests
    {
        private AppDbContext _context;
        private CartRepository _repository;

        [SetUp]
        public void Setup()
        {
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;
            
            _context = new AppDbContext(options);
            _repository = new CartRepository(_context);
        }

        [TearDown]
        public void TearDown()
        {
            _context.Dispose();
        }

        [Test]
        public async Task GetCartForUserAsync_ReturnsUserCartItems()
        {
            // Arrange
            var userId = "user123";
            var product1 = new Product { Id = 1, Name = "Product 1", Price = 10.00m, Stock = 5 };
            var product2 = new Product { Id = 2, Name = "Product 2", Price = 20.00m, Stock = 3 };
            
            _context.Products.AddRange(product1, product2);
            
            var cartItem1 = new Cart { UserId = userId, ProductId = 1, Quantity = 2 };
            var cartItem2 = new Cart { UserId = userId, ProductId = 2, Quantity = 1 };
            
            _context.Carts.AddRange(cartItem1, cartItem2);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetCartForUserAsync(userId);

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result.Count(), Is.EqualTo(2));
            
            var items = result.ToList();
            Assert.That(items[0].ProductId, Is.EqualTo(1));
            Assert.That(items[0].Quantity, Is.EqualTo(2));
            Assert.That(items[1].ProductId, Is.EqualTo(2));
            Assert.That(items[1].Quantity, Is.EqualTo(1));
        }

        [Test]
        public async Task GetCartForUserAsync_WhenNoItems_ReturnsEmptyList()
        {
            // Arrange
            var userId = "user123";

            // Act
            var result = await _repository.GetCartForUserAsync(userId);

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result.Count(), Is.EqualTo(0));
        }

        [Test]
        public async Task AddOrUpdateAsync_WhenItemDoesNotExist_CreatesNewItem()
        {
            // Arrange
            var product = new Product { Id = 1, Name = "Product 1", Price = 10.00m, Stock = 5 };
            _context.Products.Add(product);
            await _context.SaveChangesAsync();

            var cartItem = new Cart { UserId = "user123", ProductId = 1, Quantity = 3 };

            // Act
            var result = await _repository.AddOrUpdateAsync(cartItem);

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result.Id, Is.GreaterThan(0));
            Assert.That(result.UserId, Is.EqualTo("user123"));
            Assert.That(result.ProductId, Is.EqualTo(1));
            Assert.That(result.Quantity, Is.EqualTo(3));
            Assert.That(result.Product, Is.Not.Null);
            Assert.That(result.Product.Name, Is.EqualTo("Product 1"));
        }

        [Test]
        public async Task AddOrUpdateAsync_WhenItemExists_UpdatesQuantity()
        {
            // Arrange
            var product = new Product { Id = 1, Name = "Product 1", Price = 10.00m, Stock = 5 };
            _context.Products.Add(product);
            
            var existingCartItem = new Cart { UserId = "user123", ProductId = 1, Quantity = 2 };
            _context.Carts.Add(existingCartItem);
            await _context.SaveChangesAsync();

            var updatedCartItem = new Cart { UserId = "user123", ProductId = 1, Quantity = 5 };

            // Act
            var result = await _repository.AddOrUpdateAsync(updatedCartItem);

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result.Id, Is.EqualTo(existingCartItem.Id));
            Assert.That(result.Quantity, Is.EqualTo(5));
            Assert.That(result.Product, Is.Not.Null);

            // Verify only one item exists
            var count = await _context.Carts.CountAsync();
            Assert.That(count, Is.EqualTo(1));
        }

        [Test]
        public async Task RemoveAsync_WhenItemExists_RemovesItem()
        {
            // Arrange
            var cartItem = new Cart { UserId = "user123", ProductId = 1, Quantity = 2 };
            _context.Carts.Add(cartItem);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.RemoveAsync(cartItem.Id);

            // Assert
            Assert.That(result, Is.True);
            
            var count = await _context.Carts.CountAsync();
            Assert.That(count, Is.EqualTo(0));
        }

        [Test]
        public async Task RemoveAsync_WhenItemDoesNotExist_ReturnsFalse()
        {
            // Arrange
            var nonExistentId = 999;

            // Act
            var result = await _repository.RemoveAsync(nonExistentId);

            // Assert
            Assert.That(result, Is.False);
        }

        [Test]
        public async Task ClearCartAsync_RemovesAllUserItems()
        {
            // Arrange
            var userId = "user123";
            var cartItem1 = new Cart { UserId = userId, ProductId = 1, Quantity = 2 };
            var cartItem2 = new Cart { UserId = userId, ProductId = 2, Quantity = 1 };
            var otherUserItem = new Cart { UserId = "otheruser", ProductId = 3, Quantity = 1 };
            
            _context.Carts.AddRange(cartItem1, cartItem2, otherUserItem);
            await _context.SaveChangesAsync();

            // Act
            await _repository.ClearCartAsync(userId);

            // Assert
            var userItemsCount = await _context.Carts.CountAsync(c => c.UserId == userId);
            Assert.That(userItemsCount, Is.EqualTo(0));
            
            var totalItemsCount = await _context.Carts.CountAsync();
            Assert.That(totalItemsCount, Is.EqualTo(1)); // Other user's item should remain
        }

        [Test]
        public async Task ClearCartAsync_WhenNoItems_DoesNotThrow()
        {
            // Arrange
            var userId = "user123";

            // Act & Assert
            Assert.DoesNotThrowAsync(() => _repository.ClearCartAsync(userId));
        }
    }
}
