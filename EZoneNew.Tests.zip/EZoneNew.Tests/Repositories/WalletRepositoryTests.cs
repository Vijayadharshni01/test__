using EZone.Data;
using EZone.Models;
using EZone.Repositories.Service;
using Microsoft.EntityFrameworkCore;
using NUnit.Framework;

namespace EZoneNew.Tests.Repositories
{
    [TestFixture]
    public class WalletRepositoryTests
    {
        private AppDbContext _context;
        private WalletRepository _repository;

        [SetUp]
        public void Setup()
        {
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            _context = new AppDbContext(options);
            _repository = new WalletRepository(_context);
        }

        [TearDown]
        public void TearDown()
        {
            _context.Dispose();
        }

        [Test]
        public async Task GetWalletByUserIdAsync_WithValidUserId_ReturnsWallet()
        {
            // Arrange
            var userId = "user123";
            var wallet = new Wallet { UserId = userId, Balance = 100.50m };
            
            _context.Wallets.Add(wallet);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.GetWalletByUserIdAsync(userId);

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result.UserId, Is.EqualTo(userId));
            Assert.That(result.Balance, Is.EqualTo(100.50m));
        }

        [Test]
        public async Task GetWalletByUserIdAsync_WithInvalidUserId_ReturnsNull()
        {
            // Arrange
            var userId = "nonexistent";

            // Act
            var result = await _repository.GetWalletByUserIdAsync(userId);

            // Assert
            Assert.That(result, Is.Null);
        }

        [Test]
        public async Task CreateWalletAsync_WithValidUserId_ReturnsWallet()
        {
            // Arrange
            var userId = "user123";

            // Act
            var result = await _repository.CreateWalletAsync(userId);

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result.UserId, Is.EqualTo(userId));
            Assert.That(result.Balance, Is.EqualTo(0m));
            
            // Verify it was saved to database
            var savedWallet = await _context.Wallets.FirstOrDefaultAsync(w => w.UserId == userId);
            Assert.That(savedWallet, Is.Not.Null);
        }

        [Test]
        public async Task UpdateWalletAsync_WithValidWallet_ReturnsTrue()
        {
            // Arrange
            var wallet = new Wallet { UserId = "user123", Balance = 100.00m };
            _context.Wallets.Add(wallet);
            await _context.SaveChangesAsync();
            
            wallet.Balance = 150.00m;

            // Act
            var result = await _repository.UpdateWalletAsync(wallet);

            // Assert
            Assert.That(result, Is.True);
            
            // Verify the update
            var updatedWallet = await _context.Wallets.FirstOrDefaultAsync(w => w.UserId == "user123");
            Assert.That(updatedWallet!.Balance, Is.EqualTo(150.00m));
        }

        [Test]
        public async Task UpdateWalletAsync_WithInvalidWallet_ReturnsFalse()
        {
            // Arrange
            var wallet = new Wallet { Id = 999, UserId = "nonexistent", Balance = 100.00m };

            // Act
            var result = await _repository.UpdateWalletAsync(wallet);

            // Assert
            Assert.That(result, Is.False);
        }

        [Test]
        public async Task CreateWalletAsync_WithNullUserId_CreatesWalletWithNullUserId()
        {
            // Act
            var result = await _repository.CreateWalletAsync(null!);

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result.UserId, Is.Null);
            Assert.That(result.Balance, Is.EqualTo(0m));
        }

        [Test]
        public async Task DeductAmountAsync_WithValidAmount_ReturnsTrue()
        {
            // Arrange
            var userId = "user123";
            var wallet = new Wallet { UserId = userId, Balance = 100.00m };
            _context.Wallets.Add(wallet);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.DeductAmountAsync(userId, 50.00m);

            // Assert
            Assert.That(result, Is.True);
            
            // Verify the deduction
            var updatedWallet = await _context.Wallets.FirstOrDefaultAsync(w => w.UserId == userId);
            Assert.That(updatedWallet!.Balance, Is.EqualTo(50.00m));
        }

        [Test]
        public async Task AddAmountAsync_WithValidAmount_ReturnsTrue()
        {
            // Arrange
            var userId = "user123";
            var wallet = new Wallet { UserId = userId, Balance = 50.00m };
            _context.Wallets.Add(wallet);
            await _context.SaveChangesAsync();

            // Act
            var result = await _repository.AddAmountAsync(userId, 25.00m);

            // Assert
            Assert.That(result, Is.True);
            
            // Verify the addition
            var updatedWallet = await _context.Wallets.FirstOrDefaultAsync(w => w.UserId == userId);
            Assert.That(updatedWallet!.Balance, Is.EqualTo(75.00m));
        }
    }
}