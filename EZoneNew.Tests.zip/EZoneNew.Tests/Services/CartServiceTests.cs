using NUnit.Framework;
using Moq;
using EZone.Business.Interface;
using EZone.Business.Service;
using EZone.Models;
using EZone.Repositories.Interface;

namespace EZoneNew.Tests.Services
{
    [TestFixture]
    public class CartServiceTests
    {
        private Mock<ICartRepository> _mockCartRepository;
        private CartService _cartService;

        [SetUp]
        public void Setup()
        {
            _mockCartRepository = new Mock<ICartRepository>();
            _cartService = new CartService(_mockCartRepository.Object);
        }

        [Test]
        public async Task GetCartAsync_ReturnsCartItems()
        {
            // Arrange
            var userId = "user123";
            var cartItems = new List<Cart>
            {
                new Cart { Id = 1, UserId = userId, ProductId = 1, Quantity = 2 },
                new Cart { Id = 2, UserId = userId, ProductId = 2, Quantity = 1 }
            };
            _mockCartRepository.Setup(x => x.GetCartForUserAsync(userId))
                .ReturnsAsync(cartItems);

            // Act
            var result = await _cartService.GetCartAsync(userId);

            // Assert
            Assert.That(result, Is.EqualTo(cartItems));
            _mockCartRepository.Verify(x => x.GetCartForUserAsync(userId), Times.Once);
        }

        [Test]
        public async Task AddOrUpdateAsync_CreatesNewCartItem()
        {
            // Arrange
            var userId = "user123";
            var productId = 1;
            var quantity = 3;
            var expectedCartItem = new Cart 
            { 
                Id = 1, 
                UserId = userId, 
                ProductId = productId, 
                Quantity = quantity 
            };
            _mockCartRepository.Setup(x => x.AddOrUpdateAsync(It.IsAny<Cart>()))
                .ReturnsAsync(expectedCartItem);

            // Act
            var result = await _cartService.AddOrUpdateAsync(userId, productId, quantity);

            // Assert
            Assert.That(result, Is.EqualTo(expectedCartItem));
            _mockCartRepository.Verify(x => x.AddOrUpdateAsync(It.Is<Cart>(c => 
                c.UserId == userId && c.ProductId == productId && c.Quantity == quantity)), 
                Times.Once);
        }

        [Test]
        public async Task RemoveAsync_WhenItemExists_ReturnsTrue()
        {
            // Arrange
            var cartItemId = 1;
            _mockCartRepository.Setup(x => x.RemoveAsync(cartItemId))
                .ReturnsAsync(true);

            // Act
            var result = await _cartService.RemoveAsync(cartItemId);

            // Assert
            Assert.That(result, Is.True);
            _mockCartRepository.Verify(x => x.RemoveAsync(cartItemId), Times.Once);
        }

        [Test]
        public async Task RemoveAsync_WhenItemDoesNotExist_ReturnsFalse()
        {
            // Arrange
            var cartItemId = 999;
            _mockCartRepository.Setup(x => x.RemoveAsync(cartItemId))
                .ReturnsAsync(false);

            // Act
            var result = await _cartService.RemoveAsync(cartItemId);

            // Assert
            Assert.That(result, Is.False);
            _mockCartRepository.Verify(x => x.RemoveAsync(cartItemId), Times.Once);
        }

        [Test]
        public async Task ClearCartAsync_CallsRepository()
        {
            // Arrange
            var userId = "user123";
            _mockCartRepository.Setup(x => x.ClearCartAsync(userId))
                .Returns(Task.CompletedTask);

            // Act
            await _cartService.ClearCartAsync(userId);

            // Assert
            _mockCartRepository.Verify(x => x.ClearCartAsync(userId), Times.Once);
        }

        [Test]
        public async Task AddOrUpdateAsync_WithZeroQuantity_CreatesCartItem()
        {
            // Arrange
            var userId = "user123";
            var productId = 1;
            var quantity = 0;
            var expectedCartItem = new Cart 
            { 
                Id = 1, 
                UserId = userId, 
                ProductId = productId, 
                Quantity = quantity 
            };
            _mockCartRepository.Setup(x => x.AddOrUpdateAsync(It.IsAny<Cart>()))
                .ReturnsAsync(expectedCartItem);

            // Act
            var result = await _cartService.AddOrUpdateAsync(userId, productId, quantity);

            // Assert
            Assert.That(result, Is.EqualTo(expectedCartItem));
            _mockCartRepository.Verify(x => x.AddOrUpdateAsync(It.Is<Cart>(c => 
                c.Quantity == quantity)), Times.Once);
        }

        [Test]
        public async Task AddOrUpdateAsync_WithNegativeQuantity_CreatesCartItem()
        {
            // Arrange
            var userId = "user123";
            var productId = 1;
            var quantity = -1;
            var expectedCartItem = new Cart 
            { 
                Id = 1, 
                UserId = userId, 
                ProductId = productId, 
                Quantity = quantity 
            };
            _mockCartRepository.Setup(x => x.AddOrUpdateAsync(It.IsAny<Cart>()))
                .ReturnsAsync(expectedCartItem);

            // Act
            var result = await _cartService.AddOrUpdateAsync(userId, productId, quantity);

            // Assert
            Assert.That(result, Is.EqualTo(expectedCartItem));
            _mockCartRepository.Verify(x => x.AddOrUpdateAsync(It.Is<Cart>(c => 
                c.Quantity == quantity)), Times.Once);
        }
    }
}
