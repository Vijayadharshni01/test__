using NUnit.Framework;
using Moq;
using EZone.Business.Interface;
using EZone.Business.Service;
using EZone.Models;
using EZone.Repositories.Interface;
using EZone.Data;
using Microsoft.EntityFrameworkCore;

namespace EZoneNew.Tests.Services
{
    [TestFixture]
    public class OrderServiceTests
    {
        private Mock<IOrderRepository> _mockOrderRepository;
        private Mock<IWalletService> _mockWalletService;
        private Mock<AppDbContext> _mockDbContext;
        private OrderService _orderService;

        [SetUp]
        public void Setup()
        {
            _mockOrderRepository = new Mock<IOrderRepository>();
            _mockWalletService = new Mock<IWalletService>();
            _mockDbContext = new Mock<AppDbContext>();
            _orderService = new OrderService(_mockOrderRepository.Object, _mockWalletService.Object, _mockDbContext.Object);
        }

        [Test]
        public async Task PlaceOrderAsync_WithWalletPayment_WhenSufficientBalance_SetsStatusToSuccess()
        {
            // Arrange
            var userId = "user123";
            var paymentMethod = "wallet";
            var totalAmount = 100.00m;
            
            var product = new Product { Id = 1, Name = "Test Product", Price = 50.00m, Stock = 10 };
            var cartItems = new List<Cart>
            {
                new Cart { Id = 1, UserId = userId, ProductId = 1, Quantity = 2, Product = product }
            };

            var mockCartsDbSet = new Mock<DbSet<Cart>>();
            mockCartsDbSet.Setup(x => x.Where(It.IsAny<System.Linq.Expressions.Expression<Func<Cart, bool>>>()))
                .Returns(cartItems.AsQueryable());

            _mockDbContext.Setup(x => x.Carts).Returns(mockCartsDbSet.Object);
            _mockDbContext.Setup(x => x.Products).Returns(new Mock<DbSet<Product>>().Object);
            
            _mockWalletService.Setup(x => x.HasSufficientBalanceAsync(userId, totalAmount))
                .ReturnsAsync(true);
            _mockWalletService.Setup(x => x.DeductAmountAsync(userId, totalAmount))
                .ReturnsAsync(true);

            var expectedOrder = new Order
            {
                Id = 1,
                UserId = userId,
                PaymentMethod = paymentMethod,
                TotalAmount = totalAmount,
                Status = "Success"
            };
            _mockOrderRepository.Setup(x => x.AddOrderAsync(It.IsAny<Order>()))
                .ReturnsAsync(expectedOrder);

            // Act
            var result = await _orderService.PlaceOrderAsync(userId, paymentMethod);

            // Assert
            Assert.That(result, Is.EqualTo(expectedOrder));
            _mockWalletService.Verify(x => x.HasSufficientBalanceAsync(userId, totalAmount), Times.Once);
            _mockWalletService.Verify(x => x.DeductAmountAsync(userId, totalAmount), Times.Once);
        }

        [Test]
        public async Task PlaceOrderAsync_WithWalletPayment_WhenInsufficientBalance_ThrowsException()
        {
            // Arrange
            var userId = "user123";
            var paymentMethod = "wallet";
            var totalAmount = 100.00m;
            
            var product = new Product { Id = 1, Name = "Test Product", Price = 50.00m, Stock = 10 };
            var cartItems = new List<Cart>
            {
                new Cart { Id = 1, UserId = userId, ProductId = 1, Quantity = 2, Product = product }
            };

            var mockCartsDbSet = new Mock<DbSet<Cart>>();
            mockCartsDbSet.Setup(x => x.Where(It.IsAny<System.Linq.Expressions.Expression<Func<Cart, bool>>>()))
                .Returns(cartItems.AsQueryable());

            _mockDbContext.Setup(x => x.Carts).Returns(mockCartsDbSet.Object);
            
            _mockWalletService.Setup(x => x.HasSufficientBalanceAsync(userId, totalAmount))
                .ReturnsAsync(false);

            // Act & Assert
            Exception? thrownException = null;
            try
            {
                await _orderService.PlaceOrderAsync(userId, paymentMethod);
            }
            catch (Exception ex)
            {
                thrownException = ex;
            }
            
            Assert.That(thrownException, Is.Not.Null);
            Assert.That(thrownException.Message, Does.Contain("Insufficient wallet balance"));
        }

        [Test]
        public async Task PlaceOrderAsync_WithCreditCardPayment_SetsStatusToPending()
        {
            // Arrange
            var userId = "user123";
            var paymentMethod = "creditcard";
            var totalAmount = 100.00m;
            
            var product = new Product { Id = 1, Name = "Test Product", Price = 50.00m, Stock = 10 };
            var cartItems = new List<Cart>
            {
                new Cart { Id = 1, UserId = userId, ProductId = 1, Quantity = 2, Product = product }
            };

            var mockCartsDbSet = new Mock<DbSet<Cart>>();
            mockCartsDbSet.Setup(x => x.Where(It.IsAny<System.Linq.Expressions.Expression<Func<Cart, bool>>>()))
                .Returns(cartItems.AsQueryable());

            _mockDbContext.Setup(x => x.Carts).Returns(mockCartsDbSet.Object);
            _mockDbContext.Setup(x => x.Products).Returns(new Mock<DbSet<Product>>().Object);

            var expectedOrder = new Order
            {
                Id = 1,
                UserId = userId,
                PaymentMethod = paymentMethod,
                TotalAmount = totalAmount,
                Status = "Pending"
            };
            _mockOrderRepository.Setup(x => x.AddOrderAsync(It.IsAny<Order>()))
                .ReturnsAsync(expectedOrder);

            // Act
            var result = await _orderService.PlaceOrderAsync(userId, paymentMethod);

            // Assert
            Assert.That(result, Is.EqualTo(expectedOrder));
            _mockWalletService.Verify(x => x.HasSufficientBalanceAsync(It.IsAny<string>(), It.IsAny<decimal>()), Times.Never);
            _mockWalletService.Verify(x => x.DeductAmountAsync(It.IsAny<string>(), It.IsAny<decimal>()), Times.Never);
        }

        [Test]
        public async Task PlaceOrderAsync_WhenCartIsEmpty_ThrowsException()
        {
            // Arrange
            var userId = "user123";
            var paymentMethod = "creditcard";
            
            var mockCartsDbSet = new Mock<DbSet<Cart>>();
            mockCartsDbSet.Setup(x => x.Where(It.IsAny<System.Linq.Expressions.Expression<Func<Cart, bool>>>()))
                .Returns(new List<Cart>().AsQueryable());

            _mockDbContext.Setup(x => x.Carts).Returns(mockCartsDbSet.Object);

            // Act & Assert
            Exception? thrownException = null;
            try
            {
                await _orderService.PlaceOrderAsync(userId, paymentMethod);
            }
            catch (Exception ex)
            {
                thrownException = ex;
            }
            
            Assert.That(thrownException, Is.Not.Null);
            Assert.That(thrownException.Message, Does.Contain("Cart is empty"));
        }

        [Test]
        public async Task GetOrdersAsync_ReturnsUserOrders()
        {
            // Arrange
            var userId = "user123";
            var orders = new List<Order>
            {
                new Order { Id = 1, UserId = userId, Status = "Success" },
                new Order { Id = 2, UserId = userId, Status = "Pending" }
            };
            _mockOrderRepository.Setup(x => x.GetOrdersByUserAsync(userId))
                .ReturnsAsync(orders);

            // Act
            var result = await _orderService.GetOrdersAsync(userId);

            // Assert
            Assert.That(result, Is.EqualTo(orders));
            _mockOrderRepository.Verify(x => x.GetOrdersByUserAsync(userId), Times.Once);
        }

        [Test]
        public async Task DeleteOrderAsync_WhenOrderExistsAndIsPending_ReturnsTrue()
        {
            // Arrange
            var orderId = 1;
            var userId = "user123";
            var order = new Order { Id = orderId, UserId = userId, Status = "Pending" };
            
            _mockOrderRepository.Setup(x => x.GetOrderByIdAsync(orderId))
                .ReturnsAsync(order);
            _mockOrderRepository.Setup(x => x.DeleteOrderAsync(orderId))
                .ReturnsAsync(true);

            // Act
            var result = await _orderService.DeleteOrderAsync(orderId, userId);

            // Assert
            Assert.That(result, Is.True);
            _mockOrderRepository.Verify(x => x.DeleteOrderAsync(orderId), Times.Once);
        }

        [Test]
        public async Task DeleteOrderAsync_WhenOrderDoesNotExist_ReturnsFalse()
        {
            // Arrange
            var orderId = 999;
            var userId = "user123";
            
            _mockOrderRepository.Setup(x => x.GetOrderByIdAsync(orderId))
                .ReturnsAsync((Order?)null);

            // Act
            var result = await _orderService.DeleteOrderAsync(orderId, userId);

            // Assert
            Assert.That(result, Is.False);
            _mockOrderRepository.Verify(x => x.DeleteOrderAsync(It.IsAny<int>()), Times.Never);
        }

        [Test]
        public async Task DeleteOrderAsync_WhenOrderBelongsToDifferentUser_ReturnsFalse()
        {
            // Arrange
            var orderId = 1;
            var userId = "user123";
            var differentUserId = "user456";
            var order = new Order { Id = orderId, UserId = differentUserId, Status = "Pending" };
            
            _mockOrderRepository.Setup(x => x.GetOrderByIdAsync(orderId))
                .ReturnsAsync(order);

            // Act
            var result = await _orderService.DeleteOrderAsync(orderId, userId);

            // Assert
            Assert.That(result, Is.False);
            _mockOrderRepository.Verify(x => x.DeleteOrderAsync(It.IsAny<int>()), Times.Never);
        }

        [Test]
        public async Task DeleteOrderAsync_WhenOrderIsNotPending_ReturnsFalse()
        {
            // Arrange
            var orderId = 1;
            var userId = "user123";
            var order = new Order { Id = orderId, UserId = userId, Status = "Success" };
            
            _mockOrderRepository.Setup(x => x.GetOrderByIdAsync(orderId))
                .ReturnsAsync(order);

            // Act
            var result = await _orderService.DeleteOrderAsync(orderId, userId);

            // Assert
            Assert.That(result, Is.False);
            _mockOrderRepository.Verify(x => x.DeleteOrderAsync(It.IsAny<int>()), Times.Never);
        }
    }
}
