using EZone.Business.Interface;
using EZone.Business.Service;
using EZone.Models;
using EZone.Repositories.Interface;
using Moq;
using NUnit.Framework;

namespace EZoneNew.Tests.Services
{
    [TestFixture]
    public class WalletServiceTests
    {
        private Mock<IWalletRepository> _mockRepository;
        private WalletService _service;

        [SetUp]
        public void Setup()
        {
            _mockRepository = new Mock<IWalletRepository>();
            _service = new WalletService(_mockRepository.Object);
        }

        [Test]
        public async Task GetWalletAsync_WithValidUserId_ReturnsWallet()
        {
            // Arrange
            var userId = "user123";
            var wallet = new Wallet { UserId = userId, Balance = 100.50m };
            _mockRepository.Setup(r => r.GetWalletByUserIdAsync(userId)).ReturnsAsync(wallet);

            // Act
            var result = await _service.GetWalletAsync(userId);

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result.UserId, Is.EqualTo(userId));
            Assert.That(result.Balance, Is.EqualTo(100.50m));
        }

        [Test]
        public async Task GetWalletAsync_WithInvalidUserId_ReturnsNull()
        {
            // Arrange
            var userId = "nonexistent";
            _mockRepository.Setup(r => r.GetWalletByUserIdAsync(userId)).ReturnsAsync((Wallet?)null);

            // Act
            var result = await _service.GetWalletAsync(userId);

            // Assert
            Assert.That(result, Is.Null);
        }

        [Test]
        public async Task CreateWalletAsync_WithValidUserId_ReturnsWallet()
        {
            // Arrange
            var userId = "user123";
            var wallet = new Wallet { UserId = userId, Balance = 0m };
            _mockRepository.Setup(r => r.CreateWalletAsync(userId)).ReturnsAsync(wallet);

            // Act
            var result = await _service.CreateWalletAsync(userId);

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result.UserId, Is.EqualTo(userId));
            Assert.That(result.Balance, Is.EqualTo(0m));
        }

        [Test]
        public async Task DeductAmountAsync_WithValidAmount_ReturnsTrue()
        {
            // Arrange
            var userId = "user123";
            var amount = 50.00m;
            _mockRepository.Setup(r => r.DeductAmountAsync(userId, amount)).ReturnsAsync(true);

            // Act
            var result = await _service.DeductAmountAsync(userId, amount);

            // Assert
            Assert.That(result, Is.True);
        }

        [Test]
        public async Task DeductAmountAsync_WithInsufficientBalance_ReturnsFalse()
        {
            // Arrange
            var userId = "user123";
            var amount = 150.00m;
            _mockRepository.Setup(r => r.DeductAmountAsync(userId, amount)).ReturnsAsync(false);

            // Act
            var result = await _service.DeductAmountAsync(userId, amount);

            // Assert
            Assert.That(result, Is.False);
        }

        [Test]
        public async Task AddAmountAsync_WithValidAmount_ReturnsTrue()
        {
            // Arrange
            var userId = "user123";
            var amount = 25.00m;
            _mockRepository.Setup(r => r.AddAmountAsync(userId, amount)).ReturnsAsync(true);

            // Act
            var result = await _service.AddAmountAsync(userId, amount);

            // Assert
            Assert.That(result, Is.True);
        }

        [Test]
        public async Task GetBalanceAsync_WithExistingWallet_ReturnsBalance()
        {
            // Arrange
            var userId = "user123";
            var wallet = new Wallet { UserId = userId, Balance = 100.50m };
            _mockRepository.Setup(r => r.GetWalletByUserIdAsync(userId)).ReturnsAsync(wallet);

            // Act
            var result = await _service.GetBalanceAsync(userId);

            // Assert
            Assert.That(result, Is.EqualTo(100.50m));
        }

        [Test]
        public async Task GetBalanceAsync_WithNonExistingWallet_ReturnsZero()
        {
            // Arrange
            var userId = "nonexistent";
            _mockRepository.Setup(r => r.GetWalletByUserIdAsync(userId)).ReturnsAsync((Wallet?)null);

            // Act
            var result = await _service.GetBalanceAsync(userId);

            // Assert
            Assert.That(result, Is.EqualTo(0m));
        }

        [Test]
        public async Task HasSufficientBalanceAsync_WithSufficientBalance_ReturnsTrue()
        {
            // Arrange
            var userId = "user123";
            var wallet = new Wallet { UserId = userId, Balance = 100.00m };
            var amount = 50.00m;
            _mockRepository.Setup(r => r.GetWalletByUserIdAsync(userId)).ReturnsAsync(wallet);

            // Act
            var result = await _service.HasSufficientBalanceAsync(userId, amount);

            // Assert
            Assert.That(result, Is.True);
        }

        [Test]
        public async Task HasSufficientBalanceAsync_WithInsufficientBalance_ReturnsFalse()
        {
            // Arrange
            var userId = "user123";
            var wallet = new Wallet { UserId = userId, Balance = 30.00m };
            var amount = 50.00m;
            _mockRepository.Setup(r => r.GetWalletByUserIdAsync(userId)).ReturnsAsync(wallet);

            // Act
            var result = await _service.HasSufficientBalanceAsync(userId, amount);

            // Assert
            Assert.That(result, Is.False);
        }

        [Test]
        public async Task DeductAmountAsync_WithNegativeAmount_ReturnsFalse()
        {
            // Arrange
            var userId = "user123";
            var amount = -10.00m;

            // Act
            var result = await _service.DeductAmountAsync(userId, amount);

            // Assert
            Assert.That(result, Is.False);
        }

        [Test]
        public async Task AddAmountAsync_WithNegativeAmount_ReturnsFalse()
        {
            // Arrange
            var userId = "user123";
            var amount = -10.00m;

            // Act
            var result = await _service.AddAmountAsync(userId, amount);

            // Assert
            Assert.That(result, Is.False);
        }
    }
}