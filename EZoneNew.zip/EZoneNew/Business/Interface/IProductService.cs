using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EZone.Models;

namespace EZone.Business.Interface
{
    public interface IProductService
    {
        Task<IEnumerable<Product>> GetAllAsync();
        Task<Product> GetByIdAsync(int id);
        Task<Product> CreateAsync(Product p);
        Task<Product> UpdateAsync(Product p);
        Task<bool> DeleteAsync(int id);
    }
}