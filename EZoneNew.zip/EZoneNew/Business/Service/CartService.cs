using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EZone.Models;
using EZone.Business.Interface;
using EZone.Repositories.Interface;
using EZone.Repositories.Service;
namespace EZone.Business.Service
{
    public class CartService : ICartService
    {
        private readonly ICartRepository _repo;
        public CartService(ICartRepository repo) => _repo = repo;


        public Task<Cart> AddOrUpdateAsync(int userId, int productId, int quantity)
        {
        var item = new Cart { UserId = userId, ProductId = productId, Quantity = quantity };
        return _repo.AddOrUpdateAsync(item);
        }


        public Task ClearCartAsync(int userId){
            return  _repo.ClearCartAsync(userId);
        }


        public Task<IEnumerable<Cart>> GetCartAsync(int userId){
             return _repo.GetCartForUserAsync(userId);
        }


        public Task<bool> RemoveAsync(int cartItemId){
            return _repo.RemoveAsync(cartItemId);
        }
}
    }
