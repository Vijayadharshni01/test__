using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using EZone.Business.Interface;
using EZone.Business.Service;
using EZone.Models;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using EZone.Security;

namespace EZone.Controllers
{
[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
private readonly IUserService _userService;
public AuthController(IUserService userService) => _userService = userService;


[HttpPost("register")]
public async Task<IActionResult> Register([FromBody] RegisterDto dto)
{
    var user = new User
    {
    Name = dto.Name,
    Address = dto.Address,
    PhoneNumber = dto.PhoneNumber,
    Role = dto.Role,
    Email = dto.Email,
    UserName = dto.Username
    };
var created = await _userService.RegisterAsync(user, dto.Password);
return Ok(new { created.Id, created.UserName, created.Email });
}


[HttpPost("login")]
public async Task<IActionResult> Login([FromBody] LoginDto dto, [FromServices] JwtTokenGenerator tokenGen)
{
    var user = await _userService.AuthenticateAsync(dto.Username, dto.Password);
    if (user == null)
        return Unauthorized(new { message = "Invalid credentials" });

    var token = tokenGen.GenerateToken(user);
    return Ok(new
    {
        token,
        user.Id,
        user.UserName,
        role = user.Role
    });
}

public class RegisterDto
{
public string Name { get; set; }
public string Address { get; set; }
public string PhoneNumber { get; set; }
public string Email { get; set; }
public string Username { get; set; }
public string Password { get; set; }
public string Role { get; set; }
}
public class LoginDto { public string Username { get; set; } public string Password { get; set; } }
}
}