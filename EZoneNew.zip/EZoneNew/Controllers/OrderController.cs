using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using EZone.Business.Interface;
using EZone.Business.Service;
using EZone.Data;
using Microsoft.EntityFrameworkCore;
namespace EZone.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrderController : ControllerBase
    {
    private readonly IOrderService _orderService;
    private readonly IUserService _userService;
    private readonly AppDbContext _db;


    public OrderController(IOrderService orderService, IUserService userService, AppDbContext db)
    {
    _orderService = orderService;
    _userService = userService;
    _db = db;
    }


    [HttpPost("place/{userId}")]
    public async Task<IActionResult> Place(int userId, [FromQuery] string paymentMethod)
    {
    // For wallet payment, check wallet balance
    if (paymentMethod == "wallet")
    {
        var wallet = await _db.Wallets.FirstOrDefaultAsync(w => w.UserId == userId);
        var cart = (await _db.Carts.Include(c => c.Product).Where(c => c.UserId == userId).ToListAsync());
        var total = cart.Sum(c => c.Product.Price * c.Quantity);
        if (wallet == null || wallet.Balance < total) return BadRequest(new { message = "Insufficient wallet balance" });
            wallet.Balance -= total;
            _db.Wallets.Update(wallet);
            await _db.SaveChangesAsync();
    }


var order = await _orderService.PlaceOrderAsync(userId, paymentMethod);
return Ok(order);
}


[HttpGet("user/{userId}")]
public async Task<IActionResult> GetOrders(int userId) => Ok(await _orderService.GetOrdersAsync(userId));
}
}