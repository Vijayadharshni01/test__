using Microsoft.EntityFrameworkCore;
using EZone.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace EZone.Data
{
    public class AppDbContext : IdentityDbContext<User>
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Product> Products { get; set; }
        public DbSet<Cart> Carts { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<Wallet> Wallets { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<User>().HasIndex(u => u.UserName).IsUnique();
            modelBuilder.Entity<User>().HasIndex(u => u.Email).IsUnique();

            modelBuilder.Entity<Product>().HasData(
                new Product { Id= 9, Name = "Laptop", Description = "HP Pavilion", Price = 60000, Stock = 10 },
                new Product { Id = 2, Name = "Phone", Description = "Samsung Galaxy", Price = 40000, Stock = 20 },
                new Product { Id = 3, Name = "Headphones", Description = "Sony WH-1000XM5", Price = 25000, Stock = 15 },
                new Product { Id = 4, Name = "Keyboard", Description = "Logitech Mechanical", Price = 5000, Stock = 25 },
                new Product { Id = 5, Name = "Mouse", Description = "Wireless Logitech", Price = 3000, Stock = 30 }
            );
        }
    }
}