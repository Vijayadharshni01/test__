using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EZone.Models;

namespace EZone.Repositories.Interface
{
    public interface ICartRepository
    {
        Task<IEnumerable<Cart>> GetCartForUserAsync(int userId);
        Task<Cart> AddOrUpdateAsync(Cart item);
        Task<bool> RemoveAsync(int cartItemId);
        Task ClearCartAsync(int userId);
    }
}