using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using EZone.Repositories.Interface;
using EZone.Data;
using EZone.Models;
namespace EZone.Repositories.Service
{
    public class CartRepository : ICartRepository
    {
        private readonly AppDbContext _db;
        public CartRepository(AppDbContext db) => _db = db;


        public async Task<Cart> AddOrUpdateAsync(Cart item)
        {
            var existing = await _db.Carts.FirstOrDefaultAsync(c => c.UserId == item.UserId && c.ProductId == item.ProductId);
            if (existing != null){
            existing.Quantity = item.Quantity;
            _db.Carts.Update(existing);
            await _db.SaveChangesAsync();
            return existing;
        }
            _db.Carts.Add(item);
            await _db.SaveChangesAsync();
            return item;
        }


        public async Task ClearCartAsync(int userId)
        {
            var items = _db.Carts.Where(c => c.UserId == userId);
            _db.Carts.RemoveRange(items);
            await _db.SaveChangesAsync();
        }


        public async Task<IEnumerable<Cart>> GetCartForUserAsync(int userId){
            return await _db.Carts.Include(c => c.Product).Where(c => c.UserId == userId).ToListAsync();
        }


        public async Task<bool> RemoveAsync(int cartItemId)
        {
            var item = await _db.Carts.FindAsync(cartItemId);
            if (item == null) return false;
            _db.Carts.Remove(item);
            await _db.SaveChangesAsync();
            return true;
        }        
     }
}