using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using EZone.Repositories.Interface;
using EZone.Data;
using EZone.Models;

namespace EZone.Repositories.Service
{
    public class UserRepository: IUserRepository
        {
        private readonly AppDbContext _db;
        public UserRepository(AppDbContext db){
            _db = db;
        }


        public async Task<User> AddAsync(User user)
        {
            _db.Users.Add(user);
            await _db.SaveChangesAsync();
            return user;
        }


        public async Task<User> GetByIdAsync(int id){
            return await _db.Users.FindAsync(id);
        }


        public async Task<User> GetByUsernameAsync(string username){
            return await _db.Users.FirstOrDefaultAsync(u => u.UserName == username);
        }
    }
}
